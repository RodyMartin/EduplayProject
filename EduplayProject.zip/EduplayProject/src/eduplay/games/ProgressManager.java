package eduplay.games;

import eduplay.database.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ProgressManager {

    // Método para registrar el progreso de un usuario en la base de datos
    public static void registerProgress(int userId, int gameId, int score) {
        String sql = "INSERT INTO progreso (idUsuario, idJuego, puntaje) VALUES (?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, gameId);
            preparedStatement.setInt(3, score);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejar la excepción (por ejemplo, mostrar un mensaje de error)
        }
    }
}
