package eduplay.games;

import java.util.Random;

public class SumGame {
    private static final int MAX_NUMBER = 10;
    private static final int NUM_QUESTIONS = 5; // Número de preguntas por juego
    private int score;

    public SumGame() {
        score = 0;
    }

    // Genera una pregunta de suma aleatoria y devuelve el resultado esperado
    public String generateQuestion() {
        Random random = new Random();
        int num1 = random.nextInt(MAX_NUMBER + 1);
        int num2 = random.nextInt(MAX_NUMBER + 1);
        int result = num1 + num2;
        return num1 + " + " + num2 + " = ?";
    }

    // Verifica la respuesta del usuario y actualiza el puntaje
    public boolean checkAnswer(int answer, int expected) {
        if (answer == expected) {
            score++;
            return true;
        }
        return false;
    }

    // Obtiene el puntaje del juego
    public int getScore() {
        return score;
    }
}
