package eduplay.games.ui;

import eduplay.games.SumGame;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SumGameUI extends Application {

    private SumGame sumGame;
    private Label questionLabel;
    private TextField answerField;
    private Button submitButton;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Juego de Sumas");

        // Crear una instancia del juego de sumas
        sumGame = new SumGame();

        // Crear etiqueta para la pregunta
        questionLabel = new Label();
        generateNewQuestion();

        // Campo de texto para ingresar la respuesta
        answerField = new TextField();
        answerField.setPromptText("Ingrese su respuesta");

        // Botón para enviar la respuesta
        submitButton = new Button("Enviar");
        submitButton.setOnAction(e -> checkAnswer());

        // Diseño de la ventana
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10));
        layout.getChildren().addAll(questionLabel, answerField, submitButton);

        Scene scene = new Scene(layout, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Generar una nueva pregunta de suma
    private void generateNewQuestion() {
        String question = sumGame.generateQuestion();
        questionLabel.setText(question);
    }

    // Verificar la respuesta del usuario
    private void checkAnswer() {
        String answerText = answerField.getText();
        int answer;
        try {
            answer = Integer.parseInt(answerText);
        } catch (NumberFormatException e) {
            // Manejar el caso en que la respuesta no sea un número válido
            // Por ejemplo, mostrar un mensaje de error
            return;
        }

        int expected = parseExpectedAnswer(questionLabel.getText());
        boolean correct = sumGame.checkAnswer(answer, expected);

        // Manejar la respuesta del usuario (por ejemplo, mostrar un mensaje)
        if (correct) {
            System.out.println("Respuesta correcta");
        } else {
            System.out.println("Respuesta incorrecta");
        }


        // Generar una nueva pregunta después de verificar la respuesta
        generateNewQuestion();
    }

    // Analizar la pregunta para obtener el resultado esperado
    private int parseExpectedAnswer(String question) {
        // Dividir la pregunta en partes (números y operador)
        String[] parts = question.split("\\s+");
        int num1 = Integer.parseInt(parts[0]);
        int num2 = Integer.parseInt(parts[2]);
        return num1 + num2; // Devolver la suma de los dos números
    }

    public static void main(String[] args) {
        launch(args);
    }
}
