package eduplay.user;

import eduplay.database.DatabaseConnection;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterUser extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Registro de Usuario");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(8);
        grid.setHgap(10);


        Label nameLabel = new Label("Nombre:");
        GridPane.setConstraints(nameLabel, 0, 0);
        TextField nameInput = new TextField();
        GridPane.setConstraints(nameInput, 1, 0);


        Label lastNameLabel = new Label("Apellido:");
        GridPane.setConstraints(lastNameLabel, 0, 1);
        TextField lastNameInput = new TextField();
        GridPane.setConstraints(lastNameInput, 1, 1);


        Label ageLabel = new Label("Edad:");
        GridPane.setConstraints(ageLabel, 0, 2);
        TextField ageInput = new TextField();
        GridPane.setConstraints(ageInput, 1, 2);


        Label userLabel = new Label("Nombre de Usuario:");
        GridPane.setConstraints(userLabel, 0, 3);
        TextField userInput = new TextField();
        GridPane.setConstraints(userInput, 1, 3);


        Label passwordLabel = new Label("Contraseña:");
        GridPane.setConstraints(passwordLabel, 0, 4);
        PasswordField passwordInput = new PasswordField();
        GridPane.setConstraints(passwordInput, 1, 4);


        Button registerButton = new Button("Registrar");
        GridPane.setConstraints(registerButton, 1, 5);
        registerButton.setOnAction(e -> registerUser(
                nameInput.getText(),
                lastNameInput.getText(),
                ageInput.getText(),
                userInput.getText(),
                passwordInput.getText()
        ));

        grid.getChildren().addAll(nameLabel, nameInput, lastNameLabel, lastNameInput, ageLabel, ageInput, userLabel, userInput, passwordLabel, passwordInput, registerButton);

        Scene scene = new Scene(grid, 300, 250);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void registerUser(String name, String lastName, String age, String username, String password) {
        String sql = "INSERT INTO usuario (nombre, apellido, edad, nombreUsuario, contraseña) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, lastName);
            pstmt.setInt(3, Integer.parseInt(age));
            pstmt.setString(4, username);
            pstmt.setString(5, password);
            pstmt.executeUpdate();
            System.out.println("Usuario registrado exitosamente");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
